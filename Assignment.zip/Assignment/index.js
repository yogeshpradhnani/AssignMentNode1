const express = require('express');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const port = 3000;
const mongoUrl = 'mongodb://localhost:27017';
const dbName = 'assigment';

app.use(express.json());

let db;

MongoClient.connect(mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) throw err;
    console.log('Connected to MongoDB');
    db = client.db(dbName);
});

// API for user login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const users = db.collection('assignmentdb_users');
    users.findOne({ username, password }, (err, user) => {
        if (err) throw err;

        if (user) {
            res.json({ success: true, message: 'Login successful' });
        } else {
            res.json({ success: false, message: 'Invalid credentials' });
        }
    });
});

// API to get a list of products
app.get('/products', (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const pageSize = 10;

    const products = db.collection('assignmentdb_product');
    products.find().skip((page - 1) * pageSize).limit(pageSize).toArray((err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});